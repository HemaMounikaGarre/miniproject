package com.cg.oad.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;
import com.cg.oad.service.AdSeviceImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AdController {
	
	@Autowired
	AdSeviceImpl adServiceImpl;
	List<AdDetails> productList=null;

	
	
	@PostMapping("/register")
	public void register(@RequestBody Registration registration) {
		adServiceImpl.register(registration);
	}
	@GetMapping("/getbyId/{id}")
	public AdDetails getbyId(@PathVariable("id") String uid) {
		return adServiceImpl.getById(uid);
		
	}
	
	@GetMapping("/verifyuser/{emailId}/{password}")
	public Boolean validate(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
		return adServiceImpl.validate(emailId, password);
		
	}
	
	
	
	@PostMapping("/postad")
	public void postAd(@RequestBody AdDetails adDetails) {
		adServiceImpl.postAd(adDetails);
	}
	
	@GetMapping("/getad/{category}")
	public List<AdDetails> getdetails(@PathVariable("category") String name) {
		return adServiceImpl.getd(name);
	}
	
	@DeleteMapping("/removead/{id}")
	public void deleteAdd(@PathVariable("id") String id) {
		adServiceImpl.deleteAdd(id);
	}
	@PutMapping("/update")
	public void update(@RequestBody AdDetails adDetails) {
	adServiceImpl.update(adDetails);
	}
	@GetMapping("/getall")
	public List<AdDetails> GetAll()
	{
		return adServiceImpl.GetAll();
	}
	@PostMapping("/reportad/{id}/{desc}")
	public void PostData(@PathVariable("id") String id, @PathVariable("desc") String desc)
	{
		System.out.println("in c");
		adServiceImpl.PostReport(id,desc);
	}
	@PostMapping("/upload")
	public ResponseEntity<List<AdDetails>> postAd(@RequestParam("file") MultipartFile file)throws IOException
	{
	System.out.println("Hello");


	String line,name="C:\\Users\\hgarre\\Desktop\\"+file.getOriginalFilename();
	FileReader fr=new FileReader(name);
	BufferedReader br=new BufferedReader(fr);
	AdDetails product1=new AdDetails();
	while((line=br.readLine())!=null) 
	{
	System.out.println("in controller"+line);
	AdDetails product=new AdDetails();
	String []data=line.split(",");
	product.setGenUniqId(data[0]);
	product.setContactNo(data[1]);
	product.setEmailId(data[2]);
	product.setName(data[3]);
	product.setImageUrl(data[4]);
	product.setPrice(data[5]);
	product.setCategory(data[6]);
	product.setDescription(data[7]);
	adServiceImpl.postAd(product);
	}


	if(product1!=null) {
	  return new ResponseEntity(productList,HttpStatus.OK);
	  }
	return new ResponseEntity(null,HttpStatus.NOT_FOUND);
	}

	@PostMapping("/verifypass/{email}/{password}")                                                                                                          
	  public Boolean Forgetpass(@PathVariable("email") String email, @PathVariable("password") String password) {
		System.out.println("in controller");   
		return adServiceImpl.ForgetPass(email,password);
		   
	   } 

	}


	

