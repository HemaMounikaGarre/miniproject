package com.cg.oad.service;

import java.util.List;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;

public interface AdServiceI {
	

	public void register(Registration registration);
	public Boolean validate(String mail, String password);
	
	public void update(AdDetails adDetails);
	public void postAd(AdDetails adDetails);
	public List<AdDetails> getd(String name);
	public void deleteAdd(String id);
	List<AdDetails> GetAll();
	public void PostReport(String id,String desc);
	public AdDetails getById(String id);
	public Boolean ForgetPass(String mail,String password);
	
}
