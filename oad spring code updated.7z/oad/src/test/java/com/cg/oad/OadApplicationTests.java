package com.cg.oad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OadApplicationTests {

	@Test
	void contextLoads() {
	}

}
