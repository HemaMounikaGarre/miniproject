import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vhome',
  templateUrl: './vhome.component.html',
  styleUrls: ['./vhome.component.css']
})
export class VHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
