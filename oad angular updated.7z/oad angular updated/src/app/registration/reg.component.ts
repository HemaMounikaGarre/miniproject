import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineService } from '../service/online.service';

@Component({
  selector: 'app-reg',
  templateUrl: './reg.component.html',
  styleUrls: ['./reg.component.css']
})
export class RegComponent implements OnInit {
model:any={}
  
  constructor(private router:Router,private service:OnlineService) { }

  ngOnInit() {
  }
  addUser(){
    console.log("gyjhg")
    this.service.adduser(this.model).subscribe();
    this.router.navigate(['./loginpage']);
  }

}
