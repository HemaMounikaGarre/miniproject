import { Component, OnInit } from '@angular/core';
import { OnlineService } from './service/online.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
@Component({
  selector: 'app-delete-ad',
  templateUrl: './delete-ad.component.html',
  styleUrls: ['./delete-ad.component.css']
})
export class DeleteAdComponent implements OnInit {

  constructor(private service:OnlineService, private router:Router) { }

  ngOnInit() {
  }

  
  onDelete()
  {
    Swal.fire(
      'Good job!',
      'You have deleted one item!',
      'success'
    )
  }
  onSubmit(values){
    console.log(values);
    this.service.DeleteAd(values).subscribe();
 this.router.navigate(["./adminhome"])
  }
}
