import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruhome',
  templateUrl: './ruhome.component.html',
  styleUrls: ['./ruhome.component.css']
})
export class RUHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
