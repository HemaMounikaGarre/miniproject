import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-vsearch',
  templateUrl: './vsearch.component.html',
  styleUrls: ['./vsearch.component.css']
})
export class VSearchComponent implements OnInit {
  categoryname:any;
  constructor(private router:Router) { }

  ngOnInit() {
  }
  Details(){
    console.log("data"+this.categoryname);
    localStorage.setItem("category",this.categoryname);
    this.router.navigate(['./searchdetails']);
  }
}
