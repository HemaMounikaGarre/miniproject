import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineService } from './service/online.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
result:boolean;
  constructor(private router:Router,private service:OnlineService) { }

  ngOnInit() {
  }
  check(email:string,password:string){
    
    this.service.forgetpassword(email,password).subscribe((data:boolean)=>{
      this.result=data
      if(this.result)
      {
        Swal.fire(
          'Good job!',
          'You  successfully changed ur password!',
          'success'
        )
         this.router.navigate(['./loginpage']);
      }
      else{
        Swal.fire(
          'Oops!',
          'You have entered wrong credentials!',
          'error'
        )
      }
    })
    
   
  }


}
